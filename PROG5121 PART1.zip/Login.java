import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Login class for user registration and authentication
 * PROG5121 - Part 1
 */
public class Login {
    
    // User data storage
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String cellPhone;
    
    // Constructor
    public Login() {
    }
    
    /**
     * Checks if username contains underscore and is no more than 5 characters
     */
    public boolean checkUserName(String username) {
        if (username == null || username.isEmpty()) {
            return false;
        }
        
        if (!username.contains("_")) {
            return false;
        }
        
        if (username.length() > 5) {
            return false;
        }
        
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9_]+$");
        Matcher matcher = pattern.matcher(username);
        
        return matcher.matches();
    }
    
    /**
     * Checks password complexity requirements
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.isEmpty()) {
            return false;
        }
        
        if (password.length() < 8) {
            return false;
        }
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        
        return hasCapital && hasNumber && hasSpecial;
    }
    
    /**
     * Checks cell phone number format with international code
     */
    public boolean checkCellPhoneNumber(String cellPhone) {
        if (cellPhone == null || cellPhone.isEmpty()) {
            return false;
        }
        
        if (!cellPhone.startsWith("+")) {
            return false;
        }
        
        String numberPart = cellPhone.substring(1);
        
        if (!numberPart.matches("[0-9]+")) {
            return false;
        }
        
        if (numberPart.length() > 10) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Registers a user with validation
     */
    public String registerUser(String username, String password, String firstName, String lastName, String cellPhone) {
        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);
        boolean validPhone = checkCellPhoneNumber(cellPhone);
        
        StringBuilder message = new StringBuilder();
        
        if (!validUsername) {
            message.append("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.\n");
        }
        
        if (!validPassword) {
            message.append("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n");
        }
        
        if (!validPhone) {
            message.append("Cell phone number incorrectly formatted or does not contain international code.\n");
        }
        
        if (validUsername && validPassword && validPhone) {
            this.username = username;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
            this.cellPhone = cellPhone;
            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser has been registered successfully.";
        }
        
        return message.toString().trim();
    }
    
    /**
     * Verifies login credentials
     */
    public boolean loginUser(String username, String password) {
        if (this.username == null || this.password == null) {
            return false;
        }
        return this.username.equals(username) && this.password.equals(password);
    }
    
    /**
     * Returns login status message
     */
    public String returnLoginStatus(String username, String password) {
        boolean success = loginUser(username, password);
        
        if (success) {
            return "Welcome " + this.firstName + " " + this.lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
    
    // Getters
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getCellPhone() { return cellPhone; }
}