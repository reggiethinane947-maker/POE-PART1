/**
 * Unit tests for Login class
 * PROG5121 - Part 1
 */
public class LoginTest {
    
    public static void main(String[] args) {
        Login login = new Login();
        int passed = 0;
        int failed = 0;
        
        System.out.println("===== RUNNING UNIT TESTS =====\n");
        
        // Test 1: Valid username
        System.out.print("Test 1 - Valid username 'kyl_1': ");
        if (login.checkUserName("kyl_1")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 2: Invalid username
        System.out.print("Test 2 - Invalid username 'kyle!!!!!!!': ");
        if (!login.checkUserName("kyle!!!!!!!")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 3: Valid password
        System.out.print("Test 3 - Valid password 'Ch&&sec@ke99!': ");
        if (login.checkPasswordComplexity("Ch&&sec@ke99!")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 4: Invalid password
        System.out.print("Test 4 - Invalid password 'password': ");
        if (!login.checkPasswordComplexity("password")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 5: Valid phone
        System.out.print("Test 5 - Valid phone '+27838968976': ");
        if (login.checkCellPhoneNumber("+27838968976")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 6: Invalid phone
        System.out.print("Test 6 - Invalid phone '08966553': ");
        if (!login.checkCellPhoneNumber("08966553")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 7: Successful registration
        System.out.print("\nTest 7 - Successful registration: ");
        String regResult = login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "+27838968976");
        if (regResult.contains("registered successfully")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 8: Login success
        System.out.print("Test 8 - Login success: ");
        if (login.loginUser("kyl_1", "Ch&&sec@ke99!")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 9: Login failed
        System.out.print("Test 9 - Login failed (wrong password): ");
        if (!login.loginUser("kyl_1", "wrongpass")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED");
            failed++;
        }
        
        // Test 10: Login status message
        System.out.print("Test 10 - Login status message: ");
        String status = login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!");
        if (status.equals("Welcome Kyle Smith, it is great to see you again.")) {
            System.out.println("PASSED");
            passed++;
        } else {
            System.out.println("FAILED - Got: " + status);
            failed++;
        }
        
        // Summary
        System.out.println("\n===== TEST SUMMARY =====");
        System.out.println("Passed: " + passed);
        System.out.println("Failed: " + failed);
        System.out.println("Total: " + (passed + failed));
    }
}