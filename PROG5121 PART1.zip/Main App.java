import java.util.Scanner;

/**
 * Main application for PROG5121 POE
 */
public class PROG5121POE {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
        boolean registered = false;
        
        System.out.println("===== USER REGISTRATION SYSTEM =====\n");
        
        // Registration
        while (!registered) {
            System.out.println("--- Registration ---");
            
            System.out.print("Enter username (max 5 chars, must contain _): ");
            String username = scanner.nextLine();
            
            System.out.print("Enter password (8+ chars, capital, number, special): ");
            String password = scanner.nextLine();
            
            System.out.print("Enter first name: ");
            String firstName = scanner.nextLine();
            
            System.out.print("Enter last name: ");
            String lastName = scanner.nextLine();
            
            System.out.print("Enter cell phone (with + and country code): ");
            String cellPhone = scanner.nextLine();
            
            String result = login.registerUser(username, password, firstName, lastName, cellPhone);
            System.out.println("\n" + result);
            
            if (result.contains("registered successfully")) {
                registered = true;
            } else {
                System.out.println("\nPlease try again.\n");
            }
        }
        
        // Login
        System.out.println("\n===== LOGIN =====\n");
        boolean loggedIn = false;
        
        while (!loggedIn) {
            System.out.print("Enter username: ");
            String loginUser = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String loginPass = scanner.nextLine();
            
            String status = login.returnLoginStatus(loginUser, loginPass);
            System.out.println("\n" + status);
            
            if (status.contains("Welcome")) {
                loggedIn = true;
            } else {
                System.out.println("\nPlease try again.\n");
            }
        }
        
        scanner.close();
    }
}